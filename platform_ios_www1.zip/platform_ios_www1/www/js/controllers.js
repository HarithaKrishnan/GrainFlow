angular.module('cargill.grainflow.controllers', [])
.controller('initCtrl', function ($scope,$rootScope) {


            })

//home page control
.controller('homeCtrl', function ($scope, $http, $stateParams, $window, $ionicSlideBoxDelegate, $ionicLoading,$rootScope) {

            $scope.checkConnectionExists = function () {
            ionic.Platform.ready(function(){
                                 if(checkNetworkConnection())
                                 return true;
                                 else
                                 return false;
                                 });
            };



            })

//my favourites apge contorl

.controller('favouritesCtrl', function ($scope, $window) {
            $scope.callPage = function (page) {
            $window.location.href = page;
            };
            //check if any favourites are there
            $scope.navTitle='<p class="icon ion-ios7-star gf-more-info-icon-gold-color"><span class="gf-white-color"> Favourites</span></p>';
            var favItems = JSON.parse($window.localStorage.getItem('favs'));
            if (favItems != null && favItems.length > 0) {
            //hides initial favourite set-up screen
            $scope.hideDeleteButton = false;
            $scope.hideTopSection = true;
            } else {
            //shows initial favourite set-up screen
            $scope.hideDeleteButton = true;
            $scope.hideTopSection = false;
            }

            //delete button event
            $scope.onItemDelete = function (item) {
            //clear seelcted favourite item
            $scope.clearOneFavitem(item.favName);
            //check if any favourites are there - if not, toggle favourites top section
            var favItems = JSON.parse($window.localStorage.getItem('favs'));
            if (favItems.length == 0) {
            $scope.hideDeleteButton = true;
            $scope.hideTopSection = false;
            }
            };
            //delete selected favourite
            $scope.clearOneFavitem = function (favitem) {
            var data = [];
            //read favourite items
            var arrList = JSON.parse($window.localStorage.getItem('favs'));
            for (var i = 0; i < arrList.length; i++) {
            if (arrList[i].favName != favitem) {
            //referesh favourites storage
            data.push(arrList[i]);
            }
            }
            //overwrite favourites local storage value
            $window.localStorage.setItem("favs", JSON.stringify(data));
            };

            $scope.$watch(function () {
                          return $window.localStorage.getItem('favs');
                          }, function (lsData) {
                          //alert(JSON.parse(lsData));
                          $scope.favs = JSON.parse(lsData);
                          });
            })

//moreinfo list control
.controller('moreInfoListCtrl', function ($scope) {
            $scope.navTitle='<p class="icon ion-information-circled gf-more-info-icon-gold-color"><span class="gf-white-color"> More Information</span></p>';
            $scope.moreInfoList = [
                                   { title: 'Help Guide', id: 1, link: "helpguide", icon: "icon ion-ios7-help" },
                                   { title: 'Site Health and Safety', id: 2, link: "shs", icon: "icon ion-ios7-medkit" },
                                   { title: 'App Terms and Conditions', id: 3, link: "apptandcs", icon: "icon ion-clipboard" },
                                   { title: 'Other Information', id: 4, link: "otherinfo", icon: "icon ion-android-information" },
                                   { title: 'Version Information', id: 5, link: "vc", icon: "icon ion-gear-b" }
                                   ];
            })

//moreinfo details for selected item
.controller('moreInfoListDetailsCtrl', function ($scope, $stateParams) {
            var obj = $stateParams.item;
            obj = angular.fromJson(obj);
            $scope.moreInfoDetails = obj;
            })

//grain prices control
.controller('grainPrices', function ($scope, $http, $window, $ionicModal, $ionicPopup, $timeout, $stateParams, $ionicLoading, grainFlowService,$rootScope ) {

            //price search selected values
            $scope.selectedSite;
            $scope.selectedAcquirer;
            $scope.selectedCommodity;


            $scope.navTitle='<p class="icon ion-social-usd gf-more-info-icon-gold-color"><span class="gf-white-color"> Prices</span></p>';
            $scope.callPage = function (page) {
            //$ionicNavBarDelegate.back();
            $window.location.href = page;
            };
            $scope.txtDate="20-Jan-2014";
            //Triggered on a button click - add to favorites on grain prices screen
            /* $scope.showPopup = function (site, acq, comm, pt) {
             $scope.data = {}
             // An elaborate, custom popup
             var addFavPopup = $ionicPopup.show({
             template: '<input type="text" ng-model="data.favName" autofocus>',
             title: 'Enter Favourite Name',
             subTitle: 'This name will appear in your favourites',
             scope: $scope,
             buttons: [
             { text: 'Cancel' },
             {
             text: '<b>Save</b>',
             type: 'button-positive',
             onTap: function (e) {
             if (!$scope.data.favName) {
             //don't allow the user to close unless the favourite name is entered
             e.preventDefault();
             } else {
             //add it to the localstorage
             $scope.addToFavList($scope.data.favName, site, acq, comm, pt);
             }
             }
             },
             ]
             });
             addFavPopup.then(function (favName) {
             //close the popup window
             addFavPopup.close();
             });
             }
             */
            //clear all favourites
            $scope.clearFavs = function () {
            $window.localStorage.clear();
            };

            // network unavailable alert dialog
            $scope.showNetworkAlert = function() {
            var alertPopup = $ionicPopup.alert({
                                               template: 'A network related error occurred. Please make sure you are connected to the internet.'
                                               });
            alertPopup.then(function(res) {
                            $window.location.href = "#/app/home";

                            });
            };

            //server timeout popup

            $scope.timeoutAlert = function() {
            var alertPopup = $ionicPopup.alert({
                                               template: 'An internal server error occurred. Please try again later.'
                                               });
            alertPopup.then(function(res) {
                            $window.location.href = "#/app/home";

                            });
            };


            //load grain prices
            $scope.doPriceRefresh = function (site, acq, comm, pt, txtDate) {
            site = angular.fromJson(site);
            acq = angular.fromJson(acq);
            comm = angular.fromJson(comm);
            pt = angular.fromJson(pt);
            var res= grainFlowService.setPriceSearchPrevSelection(site,acq,comm,pt);

            //alert(site.ObjectID + "-" + acq.ObjectID + "-" + pt.value + "-" + comm.ObjectID + "-" + txtDate);
            //call service fucntion to fetch values
            //$scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });
            /*grainFlowService.getGrainPrices(site.ObjectID, acq.ObjectID, comm.ObjectID, pt.value, txtDate).then(function (promise) {
             $scope.Prices = promise;
             // $scope.loading.hide();

             }).finally(function () {
             //$scope.$broadcast('scroll.refreshComplete');
             //$scope.$apply()
             });*/
            $scope.selectedSite = site;
            $scope.selectedAcq = acq;
            $scope.selectedBinGrade = comm;
            $scope.selectedPricingType = pt;
            var obj = {
            favName: site.SiteName,
            siteObj: site.ObjectID,
            acqObj: acq.ObjectID,
            binGradeObj: comm.ObjectID,
            pricingType: pt.value
            };

            //alert("#/app/favpricesearch/" + JSON.stringify(obj));
            $window.location.href = "#/app/favpricesearch/" + JSON.stringify(obj);
            };




            $scope.loadSelectionCriteria = function () {
            $scope.isConnectionExists = checkNetworkConnection();
            if(!$scope.isConnectionExists)
            {
            // Stop the loading screen

            $ionicLoading.hide();
            $scope.showNetworkAlert();
            }
            else
            {
            var promise = grainFlowService.getGrainPricesSelectionCriteria();
            promise.then(function(promise) { // success callback
                         $scope.Sites = promise.sites;
                         $scope.Commodites = promise.commodities;
                         $scope.Acquirers = promise.acquirers;

                         var obj = grainFlowService.getPriceSearchPrevSelection();

                         $scope.PricesOptions = [{ ObjectID:1, name: 'Select All', value: 'A' }, { ObjectID:2, name: 'Cash Only', value: 'C' }, { ObjectID:3, name: 'Pool Only', value: 'P' }]

                         if(obj.site != null)
                             $scope.site = obj.site;
                          else
                            $scope.site = $scope.Sites[0];


                          if(obj.acq != null)
                              $scope.acq = obj.acq;
                           else
                             $scope.acq = $scope.Acquirers[0];

                          if(obj.comm != null)
                              $scope.comm = obj.comm;
                            else
                              $scope.comm = $scope.Commodites[0];

                          if(obj.pt != null)
                              $scope.pt = obj.pt;
                              else
                              $scope.pt = $scope.PricesOptions[1];



                         }, function(rejectParam) { // error callback with reason
                         // Stop the loading screen
                         $ionicLoading.hide();
                         $scope.timeoutAlert();

                         }, function(notifyParam) { // notification

                         });
            /*  grainFlowService.getGrainPricesSelectionCriteria().then(function (promise) {
             alert("promise received is " + promise);
             alert(typeof promise.then);
             //alert("this is error");
             // if (typeof promise === 'object') {
             $scope.Sites = promise.sites;
             $scope.Commodites = promise.commodities;
             $scope.Acquirers = promise.acquirers;

             $scope.acq = $scope.Acquirers[0];
             $scope.site = $scope.Sites[0];
             $scope.comm = $scope.Commodites[0];
             // $scope.loading.hide();
             },function(error){
             alert("error");
             }); */
            }

            }

          $scope.loadSelectionCriteria();



            //fecth all sites
            /* $scope.sitesList = function () {

             // $scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });
             //call service fucntion to fetch values
             grainFlowService.getAllSites().then(function (promise) {
             $scope.Sites = promise;
             $scope.site = $scope.Sites[0];
             // $scope.loading.hide();
             });


             }; */

            //fetch all buyers
            /*  $scope.acqList = function () {
             //$scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });
             //call service fucntion to fetch values
             grainFlowService.getAllBuyers().then(function (promise) {
             $scope.Acquirers = promise;
             $scope.acq = $scope.Acquirers[0];
             // $scope.loading.hide();
             });
             }; */

            //fetch commodities
            /*  $scope.commodityList = function () {
             //$scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });
             //call service fucntion to fetch values
             grainFlowService.getAllCommodites().then(function (promise) {
             $scope.Commodites = promise;
             $scope.comm = $scope.Commodites[0];
             // $scope.loading.hide();
             });
             }; */

            //price type
            $scope.priceType = function () {
            $scope.PricesOptions = [{ name: 'Select All', value: 'A' }, { name: 'Cash Only', value: 'C' }, { name: 'Pool Only', value: 'P' }]
            $scope.pt = $scope.PricesOptions[0];
            };



            })

.directive('onLastRepeat', function () {
           return function (scope, element, attrs) {
           if (scope.$last)
             //setTimeout(function () {
                                       scope.$emit('onRepeatLast', element, attrs);
              //                       }, 1000);
           };
           })



//grain prices for selected favourite item
.controller('grainPricesForSelctedFavourite', function ($scope, $http, $ionicModal, $stateParams, $ionicLoading, grainFlowService,$ionicNavBarDelegate,$ionicPopup,$window,$rootScope) {
            $scope.phoneno="1800447246";
            $scope.order = "Acquirer";
            $scope.isReverse ="false";
            $scope.isDataExists="false";
            $scope.showErrorMessage="false";
            $scope.isDefaultOrder =true;
            $scope.isPriceOrder = false;
            $scope.isGradeOrder = false;
            $scope.isBuyerOrder = false;
            //$scope.priceBlur = "false";

            //show grain prices from favourites
            $scope.showSelectedFavPrices = function () {
            //$scope.priceBlur = "false";
            $scope.isConnectionExists = checkNetworkConnection();

            if(!$scope.isConnectionExists)
            {
            // Stop the loading screen
            $ionicLoading.hide();
            $scope.showNetworkAlert();
            }
            else
            {
            var obj = $stateParams.item;
            obj = angular.fromJson(obj);
            $scope.favDetails = obj;

            //TODO: replace 20-jan-2014 with getCurrentDateString()  "20-jan-2014"
            var promise = grainFlowService.getGrainPrices(obj.siteObj, obj.acqObj, obj.binGradeObj, obj.pricingType, "20-jan-2014");
            promise.then(function(promise) { // success callback
                         $scope.FavGrainPrices = "";//promise.GrainPrices;
                         $scope.PriceSearchResults = promise.GrainPrices;
                         $scope.GrainPricesValidity = promise.GrainPricesValidity;
                         $scope.ResultsCount = $scope.PriceSearchResults.length;
                         if(angular.isUndefined($scope.PriceSearchResults.length) || $scope.PriceSearchResults.length === null || $scope.PriceSearchResults.length==0)
                         {
                         $scope.isDataExists="false";
                         $scope.showErrorMessage = "true";
                         }
                         else
                         {
                         $scope.showPopup($scope.PriceSearchResults.length);
                         $scope.isDataExists="true";
                         $scope.showErrorMessage = "false";
                         $scope.order = "";
                         $scope.isReverse ="false";
                         $scope.isDefaultOrder =true;
                         $scope.isPriceOrder = false;
                         $scope.isGradeOrder = false;
                         $scope.isBuyerOrder = false;
                         }
                         $scope.$broadcast('scroll.refreshComplete');
                         // $scope.$apply();
                         $ionicLoading.hide();

                         }, function(rejectParam) { // error callback with reason
                         // Stop the loading screen
                         $ionicLoading.hide();
                         $scope.timeoutAlert();

                         }, function(notifyParam) { // notification

                         });
            }

            }

            $scope.showResults = function(){
                $scope.FavGrainPrices = $scope.PriceSearchResults;
            };

            //server timeout popup

            $scope.timeoutAlert = function() {
            var alertPopup = $ionicPopup.alert({
                                               template: 'An internal server error occurred. Please try again later.'
                                               });
            alertPopup.then(function(res) {
                            $window.location.href = "#/app/home";

                            });
            };

            // network unavailable alert dialog
            $scope.showNetworkAlert = function() {
            var alertPopup = $ionicPopup.alert({
                                               template: 'A network related error occurred. Please make sure you are connected to the internet.'
                                               });
            alertPopup.then(function(res) {
                            $window.location.href = "#/app/home";

                            });
            };


            // A confirm dialog
           $scope.showConfirm = function() {
               var confirmPopup = $ionicPopup.confirm({
                 title: 'Grain Prices',
                 template: "<br/><div><p class='gf-text-align-center'>" + $scope.GrainPricesValidity.Date +"<br/>"+ $scope.GrainPricesValidity.ValidityMsg +"<br/>"+ $scope.GrainPricesValidity.FromHour +" - "+ $scope.GrainPricesValidity.EndHour + " " + $scope.GrainPricesValidity.tt + " " + $scope.GrainPricesValidity.TimeZone +"</p></div>"
               });
               confirmPopup.then(function(res) {
                 if(res) {
                   //$scope.PriceAlertMsgAccepted();
                                 confirmPopup.close();
                                 //$scope.priceBlur = "true";

                 } else {
                   //$scope.PriceAlertMsgDeclined();
                                 confirmPopup.close();
                                 $window.location.href = "#/app/pricesearch";
                 }
               });
           }

            $scope.$on('onRepeatLast', function (scope, element, attrs) {
                      // $scope.openPriceAlertModal();
                      //$scope.showConfirm();
                      $scope.showPopup();
                       });

            $scope.goBack = function () {
            $ionicNavBarDelegate.back();
            };

            $scope.priceRefresh = function () {
            $scope.showSelectedFavPrices();
            };

            $scope.AddToFavorites = function(){
            // $rootScope.$broadcast("AddToFavoriteEvent", {});
            //  alert($scope.favDetails.siteObj);
            //    alert($scope.favDetails.pricingType);
            $scope.showPopup1($scope.favDetails.siteObj,$scope.favDetails.acqObj,$scope.favDetails.binGradeObj,$scope.favDetails.pricingType);
            };

            //Triggered on a button click - add to favorites on grain prices screen
            $scope.showPopup1 = function (site, acq, comm, pt) {
            $scope.data = {}
            // An elaborate, custom popup
            var addFavPopup = $ionicPopup.show({
                                               template: '<input type="text" ng-model="data.favName" autofocus>',
                                               title: 'Enter Favourite Name',
                                               subTitle: 'This name will appear in your favourites',
                                               scope: $scope,
                                               buttons: [
                                                         { text: 'Cancel' },
                                                         {
                                                         text: '<b>Save</b>',
                                                         type: 'button-positive',
                                                         onTap: function (e) {
                                                         if (!$scope.data.favName) {
                                                         //don't allow the user to close unless the favourite name is entered
                                                         e.preventDefault();
                                                         } else {
                                                         //add it to the localstorage
                                                         $scope.addToFavList($scope.data.favName, site, acq, comm, pt);
                                                         }
                                                         }
                                                         },
                                                         ]
                                               });
            addFavPopup.then(function (favName) {
                             //close the popup window
                             addFavPopup.close();
                             });
            }

            //Triggered on a button click - add to favorites on grain prices screen
            $scope.showPopup = function () {


            $scope.data = {}
            // An elaborate, custom popup
            var grainPricesPopup = $ionicPopup.show({
                                              template: "<br/><br/><div><h3 class='gf-text-align-center' style='color:#fff'> Your search returned " + $scope.ResultsCount + "  results</h3></div><div><p class='gf-text-align-center'>" + $scope.GrainPricesValidity.Date +"<br/>"+ $scope.GrainPricesValidity.ValidityMsg +"<br/>"+ $scope.GrainPricesValidity.FromHour +" - "+ $scope.GrainPricesValidity.EndHour + " " + $scope.GrainPricesValidity.tt + " " + $scope.GrainPricesValidity.TimeZone +"</p></div>",
                                               //title: 'Grain Prices',
                                               scope: $scope,
                                               buttons: [
                                                         { text: 'Decline',
                                                         type: 'button button-full gf-modal-button-default',
                                                         onTap: function (e) {
                                                         grainPricesPopup.close();
                                                         $window.location.href = "#/app/pricesearch";
                                                         }
                                                         },

                                                         {
                                                         text: 'Accept',

                                                         type: 'button button-full gf-modal-button-default',
                                                         onTap: function (e) {
                                                         grainPricesPopup.close();
                                                         $scope.showResults();
                                                      //  $scope.priceBlur = "true";






                                                         }
                                                         },
                                                         ]
                                               });

            }


            //add price search secltion to favourites
            $scope.addToFavList = function (favName, site, acq, comm, pt) {

            //value from modal dialog
            $scope.favName = favName;
            //alert($scope.favName + " --" + site.ObjectID + "-" + acq.ObjectID + "-" + comm.ObjectID + "-" +  pt.value);
            var arrList = JSON.parse($window.localStorage.getItem('favs'));
            //create an object
            var favObj = {
            favName: favName,
            siteObj: site,
            acqObj: acq,
            binGradeObj: comm,
            pricingType: pt
            };
            // on null - always be null on first time
            if (arrList == null) {
            var data = [];
            data.push(favObj);
            $window.localStorage.setItem("favs", JSON.stringify(data));
            }
            else {
            //arrList.push("Cash Price at " + $scope.newDataItem);
            arrList.push(favObj);
            //alert(JSON.stringify(arrList));
            $window.localStorage.setItem("favs", JSON.stringify(arrList));
            }
            };

            $scope.setOrder = function (order) {
            $scope.order = order;
            $scope.isDefaultOrder =false;
            $scope.isReverse ="false";
            if($scope.order==="Price")
            {
            $scope.isReverse ="true";
            $scope.isPriceOrder = true;
            $scope.isGradeOrder = false;
            $scope.isBuyerOrder = false;

            }
            if($scope.order==="Acquirer")
            {
            $scope.isPriceOrder = false;
            $scope.isGradeOrder = false;
            $scope.isBuyerOrder = true;

            }
            if($scope.order==="Grade")
            {
            $scope.isPriceOrder = false;
            $scope.isGradeOrder = true;
            $scope.isBuyerOrder = false;

            }



            // $scope.$apply();

            };
            //inital load of prices for selected favourite item
            $scope.showSelectedFavPrices();


            $scope.modalTitle = 'Enter Favourite Name';
            $scope.validationErrorMessage = "Name must be non-blank with minimum 4 characters and maximum 20 characters";
            $scope.FavNameAlreadyExistsErrorMessage = "A Favourite with the same name already exists.";
            // Create and load the Modal
            $ionicModal.fromTemplateUrl('new-favourite.html', function(modal) {
                                        $scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });



                                        $scope.taskModal = modal;
                                        $scope.taskModal.favName ="";
                                        $scope.taskModal.MatchingPattern=/.*\S.*/;
                                        $scope.taskModal.showModalErrorMessage =false;
                                        $scope.taskModal.showNameExistsErrorMessage = false;
                                        $scope.taskModal.validationErrorMessage = $scope.validationErrorMessage ;
                                        $scope.taskModal.FavNameAlreadyExistsErrorMessage = $scope.FavNameAlreadyExistsErrorMessage;


                                        }, {
                                        scope: $scope,
                                        animation: 'slide-in-up',
                                        backdropClickToClose : false,
                                        hardwareBackButtonClose :false
                                        });

            $scope.disableErrorMessage = function()
            {
            // $scope.data.showErrorMaessage=false;
            };

            $scope.removeErrorMessages = function()
            {

            // $scope.taskModal.showModalErrorMessage=false;
            $scope.taskModal.showNameExistsErrorMessage = false;
            };
            // Called when the form is submitted
            $scope.createFavourite = function(isBlank,isPatternNotMatching,isLessthanMinChar,isGreaterThanMaxChar){

            if(isBlank || isPatternNotMatching || isLessthanMinChar || isGreaterThanMaxChar)
            {
            $scope.taskModal.showModalErrorMessage=true;
            }

            else
            {
            var isAddToFavItems = false;
            var favItems = JSON.parse($window.localStorage.getItem('favs'));
            if(favItems === null || favItems.length === 0)
            {
            isAddToFavItems = true;

            }

            else{
            var isFavNameAlreadyExists = false;
            for (var i = 0; i < favItems.length; i++) {
            if (favItems[i].favName.toLowerCase() === $scope.taskModal.favName.toLowerCase()) {
            isFavNameAlreadyExists = true;
            break;
            }
            }
            if(isFavNameAlreadyExists)
            {
            $scope.taskModal.showNameExistsErrorMessage = true;

            }
            else
            {
            isAddToFavItems = true;
            }

            }

            if(isAddToFavItems)
            {
            //add it to the localstorage
            $scope.addToFavList($scope.taskModal.favName,                          $scope.favDetails.siteObj,$scope.favDetails.acqObj,$scope.favDetails.binGradeObj,$scope.favDetails.pricingType);
            $scope.CancelFavouriteAction();



            }
            }



            };

            $scope.callPage = function (page) {
            //$ionicNavBarDelegate.back();
            $window.location.href = page;
            };
            // Open our new task modal
            $scope.newFav= function() {
            $scope.taskModal.favName ="";
            $scope.taskModal.MatchingPattern=/.*\S.*/;
            $scope.taskModal.showModalErrorMessage =false;
            $scope.taskModal.showNameExistsErrorMessage = false;
            $scope.taskModal.validationErrorMessage = $scope.validationErrorMessage ;
            $scope.taskModal.FavNameAlreadyExistsErrorMessage = $scope.FavNameAlreadyExistsErrorMessage;
            $scope.taskModal.show();
            };

            // Close the new task modal
            $scope.CancelFavouriteAction = function() {
            $scope.taskModal.hide();
            };

            // Create and load the price alert Modal
            $ionicModal.fromTemplateUrl('showPriceConfirmation.html', function(modal) {
                                        $scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });
                                        $scope.priceAlertModal = modal;
                                        }, {
                                        scope: $scope,
                                        animation: 'slide-in-up',
                                        backdropClickToClose : false,
                                        hardwareBackButtonClose :false
                                        });


            // Called when the accept action from price alert modal is submitted
            $scope.PriceAlertMsgDeclined = function(){
            $scope.ClosePriceAlertModal();
            $window.location.href = "#/app/pricesearch";

            }

            $scope.PriceAlertMsgAccepted = function () {
            //$scope.priceBlur = "true";
            //$scope.showConfirm.close();

            }

            // Open new price alert  modal
            $scope.openPriceAlertModal= function() {
            $scope.priceAlertModal.show();
            };

            // Close price alert  modal
            $scope.ClosePriceAlertModal = function() {
            $scope.priceAlertModal.hide();
            };


            })



//sites by state
.controller('sitesByStateCtrl', function ($rootScope,$scope, $http, $ionicLoading, grainFlowService,$ionicPopup,$window,$ionicModal,$document) {
            $scope.lat="";
            $scope.long="";
            $scope.message="";
            $scope.mapMessage="For this function, the application opens the Maps application. Continue?";
            $scope.navTitle='<p class="icon ion-location gf-more-info-icon-gold-color"><span class="gf-white-color"> Site Contacts</span></p>';


            // begin
            // Create and load the transfer alert Modal
          /*  $ionicModal.fromTemplateUrl('showTransferConfirmationWithMessage.html', function(modal) {
              $scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });
                $scope.transferAlertModal = modal;
                  }, {
                                        scope: $scope,
                                        animation: 'slide-in-up',
                                        backdropClickToClose : false,
                                        hardwareBackButtonClose :false
                                        });
                                        */


            // Called when the accept action from transfer alert modal is submitted
            $scope.TransferAlertMsgDeclined = function(){
            $scope.CloseTransferAlertModal();


            }

            $scope.TransferAlertMsgAccepted = function(){
            //$scope.CloseTransferAlertModal();
            if (navigator.userAgent.match(/(iPod|iPhone|iPad)/))
            {
			var addMap = 'maps://maps.apple.com/?z=14&q='+ $scope.lat + ', ' + $scope.long + '&ll=' + $scope.lat + ', ' + $scope.long;
			//alert('iOs: ' + addMap);
            window.open(addMap , '_system');
            }
            else
            {
            //var addMap = 'geo:0,0?q='+ global_indirizzo + ',' + global_comune + ',' + global_provincia;
            var addMap = 'geo:0,0?q=' + $scope.lat + ',' + $scope.long;
			         //alert('Android: ' + addMap);
            window.open(addMap , '_system');
            }
            }

            // Open new price alert  modal
            $scope.openTransferAlertModal= function() {

            $scope.transferAlertModal.show();
            };

            // Close price alert  modal
            $scope.CloseTransferAlertModal = function() {
            $scope.transferAlertModal.hide();
            };
            // end

            // A confirm dialog
            $scope.showConfirm = function() {
              var confirmPopup = $ionicPopup.confirm({
              //  title: 'Consume Ice Cream',
                template: $scope.mapMessage,
                cancelText: 'Cancel', // String (default: 'Cancel'). The text of the Cancel button.
                cancelType: 'gf-modal-button-default', // String (default: 'button-default'). The type of the Cancel button.
                okText: 'Continue', // String (default: 'OK'). The text of the OK button.
                okType: 'gf-modal-button-default', // String (default: 'button-positive'). The type of the OK button.
              });

            confirmPopup.then(function(res) {
              if(res) {
                confirmPopup.close();
                $scope.TransferAlertMsgAccepted();
              } else {
                 confirmPopup.close();
              }
            });
          };

            $scope.mapLink = function(lat,long) {
            $scope.lat = lat;
            $scope.long = long;
            $scope.message=$scope.mapMessage;

            //$scope.openTransferAlertModal();

            $scope.showConfirm();

            };

            // network unavailable alert dialog
            $scope.showNetworkAlert = function() {
            var alertPopup = $ionicPopup.alert({
                                               template: 'A network related error occurred. Please make sure you are connected to the internet.'
                                               });
            alertPopup.then(function(res) {
                            $window.location.href = "#/app/home";

                            });
            };

            //server timeout popup
            $scope.timeoutAlert = function() {
            var alertPopup = $ionicPopup.alert({
                                               template: 'An internal server error occurred. Please try again later.'
                                               });
            alertPopup.then(function(res) {
                            $window.location.href = "#/app/home";

                            });
            };




            $scope.isConnectionExists = checkNetworkConnection();
            if(!$scope.isConnectionExists)
            {
            // Stop the loading screen
            $ionicLoading.hide();
            // $document.body.classList.remove('loading-active');
            $scope.showNetworkAlert();
            }

            //call service fucntion to fetch sites
            else
            {

            //call service fucntion to fetch sites
            $scope.states = grainFlowService.getStates();

            var promise = grainFlowService.getSiteContact();
            promise.then(function(promise) { // success callback
                         $scope.gfSites = promise;
                         //alert($scope.gfSites);

                         var indexedSites = [];

                         $scope.sitesToFilter = function () {
                         indexedSites = [];
                         return $scope.gfSites;
                         }

                         $scope.filterSites = function (site) {
                         var siteIsNew = indexedSites.indexOf(site.State_ObjectID) == -1;
                         if (siteIsNew) {
                         indexedSites.push(site.State_ObjectID);
                         }
                         return siteIsNew;
                         }

                         }, function(rejectParam) { // error callback with reason
                         // Stop the loading screen
                         $ionicLoading.hide();
                         $document[0].body.classList.remove('loading-active');
                         $scope.timeoutAlert();

                         }, function(notifyParam) { // notification

                         });

            }

            $scope.getStateName = function (stateId) {
            // alert(stateId + "-" + $scope.states($scope.states.StateObj) == stateId);
            return $scope.states.indexOf($scope.states.StateObj) == stateId;
            }

            $scope.selectedSite = function (site) {
            grainFlowService.setSelectedSite(site);
            $window.location.href = "#/app/selectedsitedetails";
            }


            })

//selected site details ctrl
.controller('siteContactCtrl', function ($scope, $stateParams, $ionicTabsDelegate, grainFlowService, $ionicLoading, $http, $ionicNavBarDelegate,$ionicPopup,$window,$ionicModal,$location) {
            $scope.lat ="";
            $scope.long="";
            $scope.message="";
            $scope.mapMessage="For this function, the application opens the Maps application. Continue?";
            $scope.navTitle='<p class="icon ion-location gf-more-info-icon-gold-color"><span class="gf-white-color"> Site Contacts</span></p>';
            var obj = grainFlowService.getSelectedSite();
            // obj = angular.fromJson(obj);

            $scope.site = obj;

            // network unavailable alert dialog
            $scope.showNetworkAlert = function() {
            var alertPopup = $ionicPopup.alert({
                                               template: 'A network related error occurred. Please make sure you are connected to the internet.'
                                               });
            alertPopup.then(function(res) {
                            $scope.goBack();

                            });
            };

            //server timeout popup

            $scope.timeoutAlert = function() {
            var alertPopup = $ionicPopup.alert({
                                               template: 'An internal server error occurred. Please try again later.'
                                               });
            alertPopup.then(function(res) {
                            $window.location.href = "#/app/home";

                            });
            };

            // begin
            // Create and load the transfer alert Modal
            $ionicModal.fromTemplateUrl('showTransferConfirmationWithMessage.html', function(modal) {
                                        $scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });
                                        $scope.transferAlertModal = modal;
                                        if($location.path().indexOf("selectedsitedetails")!= -1)
                                        $ionicLoading.hide();
                                        }, {
                                        scope: $scope,
                                        animation: 'slide-in-up',
                                        backdropClickToClose : false,
                                        hardwareBackButtonClose :false
                                        });


            // Called when the accept action from transfer alert modal is submitted
            $scope.TransferAlertMsgDeclined = function(){
            $scope.CloseTransferAlertModal();


            }

            // send email
            $scope.DailPhoneNumber = function()
            {
               if (navigator.userAgent.match(/(iPod|iPhone|iPad)/))
               {
                 window.location.href="tel:"+$scope.site.Phone;
               }else{
                 window.open("tel:"+$scope.site.Phone , '_system');
              }
            }

            // send email
            $scope.OpenEmail = function()
            {
               if (navigator.userAgent.match(/(iPod|iPhone|iPad)/))
               {
                 window.location.href="mailto:"+$scope.site.Email;
               }else{
                 window.open("mailto:"+$scope.site.Email  , '_system');
               }
            }

            $scope.TransferAlertMsgAccepted = function(){
            $scope.CloseTransferAlertModal();
            if (navigator.userAgent.match(/(iPod|iPhone|iPad)/))
            {
			var addMap = 'maps://maps.apple.com/?q=' + $scope.site.Lat + ', ' + $scope.site.Lng;
			//alert('iOs: ' + addMap);
            window.open(addMap , '_system');
            }
            else
            {
            //var addMap = 'geo:0,0?q='+ global_indirizzo + ',' + global_comune + ',' + global_provincia;
            var addMap = 'geo:0,0?q=' + $scope.site.Lat + ', ' + $scope.site.Lng;
			//alert('Android: ' + addMap);
            window.open(addMap , '_system');
            }
            }

            // Open new price alert  modal
            $scope.openTransferAlertModal= function() {
              $scope.transferAlertModal.show();
            };

            // Close price alert  modal
            $scope.CloseTransferAlertModal = function() {
            $scope.transferAlertModal.hide();
            };
            // end

            $scope.getSiteTurnAroundTime = function (siteObj) {

            $scope.isConnectionExists = checkNetworkConnection();
            if(!$scope.isConnectionExists)
            {
            // Stop the loading screen
            $ionicLoading.hide();
            $scope.showNetworkAlert();
            }
            else
            {
            //fetch site site opening hours time for a selected site
            var promise = grainFlowService.getSiteTurnAroundTime($scope.site.ObjectId);
            promise.then(function(promise) { // success callback
                         $scope.SiteTurnAroundTime = promise.SiteTurnaroundTimes;
                         $scope.NoSiteTurnAroundTimeRecordsExists = false;

                         if($scope.SiteTurnAroundTime != null && $scope.SiteTurnAroundTime.length >0)
                         $scope.NoSiteTurnAroundTimeRecordsExists = false;
                         else
                         $scope.NoSiteTurnAroundTimeRecordsExists = true;

                         }, function(rejectParam) { // error callback with reason
                         // Stop the loading screen
                         $ionicLoading.hide();
                         $scope.timeoutAlert();

                         }, function(notifyParam) { // notification

                         });
            }

            }

            $scope.getSiteSegregations = function (siteObj) {
            $scope.isConnectionExists = checkNetworkConnection();
            if(!$scope.isConnectionExists)
            {

            // Stop the loading screen
            $ionicLoading.hide();
            $scope.showNetworkAlert();
            }
            else
            {
            //fetch site site opening hours time for a selected site
            var promise = grainFlowService.getSiteSegregations($scope.site.ObjectId);
            promise.then(function(promise) { // success callback
                         $scope.SiteSegregations = promise.SiteSegregations;
                         $scope.NoSiteSegregationRecordsExists = false;

                         if($scope.SiteSegregations != null && $scope.SiteSegregations.length >0)
                         $scope.NoSiteSegregationRecordsExists = false;
                         else
                         $scope.NoSiteSegregationRecordsExists = true;

                         }, function(rejectParam) { // error callback with reason
                         // Stop the loading screen
                         $ionicLoading.hide();
                         $scope.timeoutAlert();

                         }, function(notifyParam) { // notification

                         });
            }
            }



            $scope.getSiteOpeningHours = function (siteObj) {
            $scope.isConnectionExists = checkNetworkConnection();
            if(!$scope.isConnectionExists)
            {
            // Stop the loading screen
            $ionicLoading.hide();
            $scope.showNetworkAlert();
            }
            else
            {
            //fetch site site opening hours time for a selected site
            var promise = grainFlowService.getSiteOpeningHours($scope.site.ObjectId);
            promise.then(function(promise) { // success callback
                         $scope.SiteDetails = promise.SiteDetails[0];
                         $scope.SiteOpeningHours = promise.SiteOpeningHours;
                         $scope.NoSiteOpeningHoursRecordsExists = false;

                         if($scope.SiteOpeningHours != null && $scope.SiteOpeningHours.length >0)
                         $scope.NoSiteOpeningHoursRecordsExists = false;
                         else
                         $scope.NoSiteOpeningHoursRecordsExists = true;

                         }, function(rejectParam) { // error callback with reason
                         // Stop the loading screen
                         $ionicLoading.hide();
                         $scope.timeoutAlert();

                         }, function(notifyParam) { // notification

                         });
            }
            }

            // A confirm dialog
            $scope.showConfirm = function() {
              var confirmPopup = $ionicPopup.confirm({
              //  title: 'Consume Ice Cream',
                template: $scope.mapMessage,
                cancelText: 'Cancel', // String (default: 'Cancel'). The text of the Cancel button.
                cancelType: 'gf-modal-button-default', // String (default: 'button-default'). The type of the Cancel button.
                okText: 'Continue', // String (default: 'OK'). The text of the OK button.
                okType: 'gf-modal-button-default', // String (default: 'button-positive'). The type of the OK button.
              });

            confirmPopup.then(function(res) {
              if(res) {
                confirmPopup.close();
                $scope.TransferAlertMsgAccepted();
              } else {
                 confirmPopup.close();
              }
            });
          };

            $scope.goBack = function () {
            $ionicNavBarDelegate.back();
            }
            $scope.mapLink = function () {
            $scope.message = $scope.mapMessage;
            $scope.showConfirm();
            //$scope.openTransferAlertModal();
            }
            })
.controller('selectedSiteOnMapCtrl', function ($scope, $stateParams, $ionicTabsDelegate, grainFlowService, $ionicLoading, $http, $ionicNavBarDelegate) {

            var obj = $stateParams.item;
            //alert(obj); //gives us the Site JSON data structure
            obj = angular.fromJson(obj);
            $scope.site = obj;
            //initialise map
            var map;
            $scope.sitesNearMyLocation = [];
            $scope.currentLocationLat = null;
            $scope.currentLocationLng = null;
            //map icon url
            var iconBase = 'http://maps.gstatic.com/mapfiles/ms2/micons/';
            //map options
            var mapOptions = {
            zoom: 13,
            center: new google.maps.LatLng(obj.Lat, obj.Lng),//-34.397, 150.644), // this should be head office geo codes
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            panControl: true,
            zoomControl: true,
            mapTypeControl: true,
            scaleControl: false,
            streetViewControl: false,
            navigationControl: true,
            disableDefaultUI: true,
            overviewMapControl: true
            };
            //add map options to div
            map = new google.maps.Map(document.getElementById("map"), mapOptions);
            //for direction services
            var directionsRenderer = new google.maps.DirectionsRenderer();
            directionsRenderer.setMap(map);
            var directionsService = new google.maps.DirectionsService();

            //fecth sites
            var allSites = null;
            //$scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });
            //call service fucntion to fetch values
            grainFlowService.getSitesLatLng().then(function (promise) {
                                                   $scope.SitesLatLng = promise;
                                                   //loop through sites lat & lng codes
                                                   angular.forEach($scope.SitesLatLng, function (value, key) {
                                                                   //if there is a match then
                                                                   if ($stateParams.item == value.Site_ObjectId) {
                                                                   //save site name to show on the page title
                                                                   $scope.siteName = value.SiteName;
                                                                   //create latlng obj
                                                                   var latlng = new google.maps.LatLng(value.Lat, value.Lng);
                                                                   //create a marker with above latlng obj
                                                                   var marker = new google.maps.Marker({ position: latlng, map: map, animation: google.maps.Animation.DROP, icon: iconBase + 'yellow-dot.png' });
                                                                   //place marker in the map
                                                                   map.panTo(marker.position);
                                                                   //create info window
                                                                   var div = document.createElement('div');
                                                                   var infoWindowContent = "<div id='infoWindow'><a> <label style='cursor:pointer;' siteLat=" + value.Lat + " siteLng=" + value.Lng + " siteObj=" + value.Site_ObjectId + " id='lblSite'> 1" + $scope.siteName + "</label></a></div>"
                                                                   var infowindow = new google.maps.InfoWindow({ content: infoWindowContent });
                                                                   //add infow window to marker click event
                                                                   new google.maps.event.addListener(marker, 'click', function () {
                                                                                                     infowindow.open(map, marker);
                                                                                                     });
                                                                   }
                                                                   })

                                                   $scope.map = map;
                                                   //$scope.loading.hide();
                                                   })

            //gets user current location & then fetches sites near to it
            $scope.getCurrentLocation = function ()
            {
            $scope.loading = $ionicLoading.show({ content: 'Getting current location...', showBackdrop: false });
            //locate user current geo codes
            navigator.geolocation.getCurrentPosition(function (pos) {
                                                     $scope.map.setCenter(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
                                                     //saving current location geocodes
                                                     $scope.currentLocationLat = pos.coords.latitude;
                                                     $scope.currentLocationLng = pos.coords.longitude;
                                                     $ionicLoading.hide();
                                                     //current location marker
                                                     var marker = new google.maps.Marker({
                                                                                         position: new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude),
                                                                                         map: map,
                                                                                         animation: google.maps.Animation.DROP,
                                                                                         icon: iconBase + 'red-dot.png' //'grn-square-lv.png'
                                                                                         });
                                                     //set zoom
                                                     map.setZoom(13);
                                                     //pan to current location
                                                     map.panTo(marker.position);
                                                     //save map to scope
                                                     $scope.map = map;
                                                     //locate sites close to you.
                                                     $scope.showSitesNearMe();
                                                     $ionicLoading.hide();
                                                     }, function (error) {
                                                     alert('Unable to get location: ' + error.message);
                                                     });
            }

            //gets the user current location
            $scope.locateMe = function () {
            if (!$scope.map) {
            return;
            }
            $scope.getCurrentLocation();
            }

            //fetches sites near user location
            $scope.showSitesNearMe = function () {
            // $scope.loading = $ionicLoading.show({ content: 'Getting current location...', showBackdrop: false });
            var m = document.getElementById("map");
            m.style.height = "80%";
            var m1 = document.getElementById("sitesList");
            m1.style.height = "20%";

            angular.forEach($scope.SitesLatLng, function (value, key) {
                            var siteObj = {
                            siteObj: value.ObjectID,
                            siteName: value.SiteName,
                            siteLat: value.Lat,
                            siteLng: value.Lng,
                            siteDistance: getDistanceFromLatLonInKm(value.Lat, value.Lng, $scope.currentLocationLat, $scope.currentLocationLng)
                            };
                            $scope.sitesNearMyLocation.push(siteObj);
                            })

            $scope.predicate = "siteDistance";
            //  $scope.loading.hide();
            }

            //gets sites near to user location
            $scope.findSitesNearMe = function () {
            if ($scope.currentLocationLat != null && $scope.currentLocationLng != null) {
            $scope.showSitesNearMe();
            }
            else {
            $scope.getCurrentLocation();
            }
            }

            //shows rote on the map
            $scope.ShowMeTheRoute = function (site) {

            //alert(new google.maps.LatLng($scope.currentLocationLat, $scope.currentLocationLng));
            //alert(new google.maps.LatLng(site.siteLat, site.siteLng));
            var dP = document.getElementById('directionsPanel')
            dP.innerHTML = "";
            var request = {
            origin: new google.maps.LatLng($scope.currentLocationLat, $scope.currentLocationLng), //'sydney, AU',
            destination: new google.maps.LatLng(site.siteLat, site.siteLng), //'melbourne, AU',
            travelMode: google.maps.DirectionsTravelMode.DRIVING,
            unitSystem: google.maps.DirectionsUnitSystem.METRIC
            };

            directionsService.route(request, function (response, status) {
                                    if (status == google.maps.DirectionsStatus.OK) {
                                    directionsRenderer.setDirections(response);
                                    } else {
                                    alert('Error: ' + status);
                                    }
                                    });


            }

            })

.controller('helpGuideCtrl', function ($scope,$ionicNavBarDelegate,$window,$ionicScrollDelegate,$location) {

            $scope.goBack = function () {
            $ionicNavBarDelegate.back();
            };
            $scope.openGrainFlowWebPage = function(){
            window.open('http://www.grainflow.com.au','_system','location=yes');
            };

            $scope.openTCPage = function() {
            $window.location.href ="#/app/apptandcs";
            };

            $scope.scrollTo = function(location) {
            /* alert(id);
             $window.location.hash ="Aravind";
             $ionicScrollDelegate.anchorScroll(id);
             alert("done"); */
            location1 = $location.hash(location);
            $ionicScrollDelegate.$getByHandle('mainScroll').anchorScroll("#"+location1);
            /* $location.hash(id);

             $ionicScrollDelegate.anchorScroll();*/
            };

            }
            )

.controller('siteHealthAndSafetyCtrl', function ($scope,$ionicNavBarDelegate) {

            $scope.goBack = function () {
            $ionicNavBarDelegate.back();
            };
            }
            )

.controller('appTermsAndConditionsCtrl', function ($scope,$ionicNavBarDelegate,$window) {

            $scope.goBack = function () {
            $ionicNavBarDelegate.back();
            };

            $scope.openGrainFlowWebPage = function(){
            window.open('http://www.awb.com.au/termsofuse/','_system','location=yes');
            };

            }
            )

.controller('otherInfoCtrl', function ($scope,$ionicNavBarDelegate,$window) {

            $scope.goBack = function () {
            $ionicNavBarDelegate.back();
            };

            $scope.openGrainFlowWebPage = function(){
            window.open('http://www.grainflow.com.au/growers','_system','location=yes');

            };

            $scope.growerLogin = function(){
            $window.location.href ="#/app/growerlogin";
            };

            }
            )

.controller('versionControlCtrl', function ($scope,$ionicNavBarDelegate) {

            $scope.goBack = function () {
            $ionicNavBarDelegate.back();
            };

            }
            )

.controller('growerCtrl', function ($scope,$ionicNavBarDelegate,$ionicModal,$ionicLoading,$window) {
            $scope.navTitle='<p class="icon ion-locked gf-more-info-icon-gold-color"><span class="gf-white-color"> Grower Login</span></p>';
            $scope.goBack = function () {
            $ionicNavBarDelegate.back();
            };
            $scope.transfer = function() {

            }
            // begin
            // Create and load the transfer alert Modal
            $ionicModal.fromTemplateUrl('showTransferConfirmation.html', function(modal) {
                                        $scope.loading = $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false });
                                        $scope.transferAlertModal = modal;
                                        $ionicLoading.hide();
                                        }, {
                                        scope: $scope,
                                        animation: 'slide-in-up',
                                        backdropClickToClose : false,
                                        hardwareBackButtonClose :false
                                        });


            // Called when the accept action from transfer alert modal is submitted
            $scope.TransferAlertMsgDeclined = function(){
            $scope.CloseTransferAlertModal();


            }

            $scope.TransferAlertMsgAccepted = function(){
            $scope.CloseTransferAlertModal();
            window.open('http://www.awb.com.au/growerportal/gcs/growerhome.aspx','_system','location=yes');
            // alert("at last");
            }

            // Open new price alert  modal
            $scope.openTransferAlertModal= function() {

            $scope.transferAlertModal.show();
            };

            // Close price alert  modal
            $scope.CloseTransferAlertModal = function() {
            $scope.transferAlertModal.hide();
            };
            // end
            }
            )

.controller('grainflowCtrl', function ($scope,$ionicNavBarDelegate) {
            $scope.navTitle='<p class="icon ion-ios7-telephone gf-more-info-icon-gold-color"><span class="gf-white-color"> Call GrainFlow</span></p>';
            $scope.goBack = function () {
            $ionicNavBarDelegate.back();
            };

            }
            )

.controller('menuCtrl', function ($scope,$window) {

            $scope.callPage = function (page) {
            //$ionicNavBarDelegate.back();
            $window.location.href = page;
            };
            }
            )

//claculates distance between two locations by geocodes
function getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
    var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(lat2 - lat1);  // deg2rad below
    var dLon = deg2rad(lon2 - lon1);
    var a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2)
    ;
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    var d = R * c; // Distance in km
    return Math.round(d,2);
}

//returns the distance
function deg2rad(deg) {
    return deg * (Math.PI / 180)
}

//returns date string in dd-mmm-yyyy format
function getCurrentDateString()
{
    var currentDate =  new Date();
    var months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var day = currentDate.getDate();
    if (day<10){
        day="0" + day;
    };

    return(day+"-"+months[currentDate.getMonth()]+"-"+currentDate.getFullYear());
}

function checkNetworkConnection() {

    var networkState = navigator.connection.type;
    var isConnectionExists = true;
    // console.info("checknetworkconnection called");
     /* var states = {};
     states[Connection.UNKNOWN]  = 'Unknown connection';
     states[Connection.ETHERNET] = 'Ethernet connection';
     states[Connection.WIFI]     = 'WiFi connection';
     states[Connection.CELL_2G]  = 'Cell 2G connection';
     states[Connection.CELL_3G]  = 'Cell 3G connection';
     states[Connection.CELL_4G]  = 'Cell 4G connection';
     states[Connection.CELL]     = 'Cell generic connection';
     states[Connection.NONE]     = 'No network connection'; */
    //if(networkState === Connection.NONE || networkState === Connection.ETHERNET)
   if(networkState === Connection.NONE)
    {
        isConnectionExists = false;

    }

    return isConnectionExists;
 }
