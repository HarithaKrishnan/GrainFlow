    /* Service*/
    angular.module('cargill.grainflow.services', [])
        .service('grainFlowService', function ($http, $q) {

            this.restApiUrl = "http://www.grainflow.com.au/api/gf.ashx/";
            this.timeOutInMilliSeconds = 30000;
            //selected site json obj default var
            this.selectedSite = "0";

            this.prevPriceSeachSite=null;
            this.prevPriceSearchAcq=null;
            this.prevPriceSearchComm=null;
            this.prevPriceSearchPt=null;

            //returns selected site json object
            this.getSelectedSite = function () {
                return this.selectedSite;
            }
            //sets selected site json object
            this.setSelectedSite = function (value) {
                this.selectedSite = value;
            }


            this.setPriceSearchPrevSelection= function(site,acq,comm,pt){
                this.prevPriceSeachSite=site;
                this.prevPriceSearchAcq=acq;
                this.prevPriceSearchComm=comm;
                this.prevPriceSearchPt=pt;
            }


            this.getPriceSearchPrevSelection = function () {
                return   {
                  site: this.prevPriceSeachSite,
                  acq: this.prevPriceSearchAcq,
                  comm: this.prevPriceSearchComm,
                  pt: this.prevPriceSearchPt
                  };
            }


            //fetch sites from restapi call
            this.getAllSites = function () {
                //this.restApiUrl + "sites.txt"
                return $http.get(this.restApiUrl + "?id=getsitesall").then(function (response) {
                    return response.data;
                });
           }

            //fetch buyers from restapi call
            this.getAllBuyers = function () {
                //this.restApiUrl + "acquirer.txt"
                return $http.get(this.restApiUrl + "?id=getacqall").then(function (response) {
                    return response.data;
                });
            }

            //fetch commodities from restapi call
            this.getAllCommodites = function () {
                //this.restApiUrl + "commodity.txt"
                return $http.get(this.restApiUrl + "?id=getcommall").then(function (response) {
                    return response.data;
                });
            }

            //fecth grain prices by site,acquirer,commodity
            this.getGrainPricesSelectionCriteria = function (siteObj, acqObj, commObj, ptVal, txtDate) {

      var deferred = $q.defer();

      $http.get(this.restApiUrl + "?id=grainpricesselectioncriteria", { timeout:this.timeOutInMilliSeconds })
        .then(function(response){
         deferred.resolve(response.data);
        },function(reject){
          // error handler
          if(reject.status === 0) {
               deferred.reject("timeout");

          } else {
             // response error status from server
             //alert("internal server error");
              deferred.reject("internal server error");
          }
        }
        );
        return deferred.promise;
            //end
            }


            //fecth grain prices by site,acquirer,commodity and price type
            this.getGrainPrices = function (siteObj, acqObj, commObj, ptVal, txtDate) {
                var deferred = $q.defer();
                //alert(this.restApiUrl + "?id=getgrainpricesbysacptdt&siteObj=" + siteObj + "&acqObj=" + acqObj + "&commObj=" + commObj + "&ptVal=" + ptVal + "&dt=" + txtDate);
      $http.get(this.restApiUrl + "?id=getgrainpricesbysacptdt&siteObj=" + siteObj + "&acqObj=" + acqObj + "&commObj=" + commObj + "&ptVal=" + ptVal + "&dt=" + txtDate, { timeout:this.timeOutInMilliSeconds }).then(function(response){
         deferred.resolve(response.data);
        },function(reject){
          // error handler
          if(reject.status === 0) {
               deferred.reject("timeout");

          } else {
             // response error status from server
             //alert("internal server error");
              deferred.reject("internal server error");
          }
        }
        );
        return deferred.promise;
            //end
            }

            //get states
            this.getStates = function()
            {
                var stateObj = [{ 'ObjecTID': 1, 'StateObj': 2, 'stateName': 'New South Wales', 'stateCode': 'NSW' },
                                { 'ObjecTID': 2, 'StateObj': 3, 'stateName': 'Victoria', 'stateCode': 'VIC' },
                                { 'ObjecTID': 3, 'StateObj': 4, 'stateName': 'Queensland', 'stateCode': 'QLD' },
                                { 'ObjecTID': 4, 'StateObj': 6, 'stateName': 'Western Australia', 'stateCode': 'WA' },
                                { 'ObjecTID': 5, 'StateObj': 5, 'stateName': 'South Australia', 'stateCode': 'SA' },
                                { 'ObjecTID': 6, 'StateObj': 7, 'stateName': 'Tasmania', 'stateCode': 'TAS' },
                                { 'ObjecTID': 7, 'StateObj': 8, 'stateName': 'Northern Territory', 'stateCode': 'NT' },
                                { 'ObjecTID': 8, 'StateObj': 1, 'stateName': 'Australian Capital Territory', 'stateCode': 'ACT' }];
                return  stateObj;
            }

            //get SiteTurnAroundTime
            this.getSiteTurnAroundTime = function (siteObj) {


    var deferred = $q.defer();

      $http.get(this.restApiUrl + "?id=getsitettbysid&sid=" + siteObj, { timeout:this.timeOutInMilliSeconds }).then(function(response){
         deferred.resolve(response.data);

        },function(reject){
          // error handler
          if(reject.status === 0) {
               deferred.reject("timeout");

          } else {
             // response error status from server
             //alert("internal server error");
              deferred.reject("internal server error");
          }
        }
        );
        return deferred.promise;
            //end
            }

            //SiteSegregations
            this.getSiteSegregations = function (siteObj) {
                 var deferred = $q.defer();

      $http.get(this.restApiUrl + "?id=getsitesegbysid&sid=" + siteObj, { timeout:this.timeOutInMilliSeconds }).then(function(response){
         deferred.resolve(response.data);
        },function(reject){
          // error handler
          if(reject.status === 0) {
               deferred.reject("timeout");

          } else {
             // response error status from server
             //alert("internal server error");
              deferred.reject("internal server error");
          }
        }
        );
        return deferred.promise;
            //end
            }

            //SiteOpeningHours
            this.getSiteOpeningHours = function (siteObj) {


      var deferred = $q.defer();

      $http.get(this.restApiUrl + "?id=getsiteohbysid&sid=" + siteObj, { timeout:this.timeOutInMilliSeconds }).then(function(response){
         deferred.resolve(response.data);
        },function(reject){
          // error handler
          if(reject.status === 0) {
               deferred.reject("timeout");

          } else {
             // response error status from server
             //alert("internal server error");
              deferred.reject("internal server error");
          }
        }
        );
        return deferred.promise;
            //end
            }

            //Site names with geocodes
            this.getSiteContact = function () {

         var deferred = $q.defer();

                 $http.get(this.restApiUrl + "?id=getsitescontacts", {  cache:true, timeout:this.timeOutInMilliSeconds }).then(function(response){
         deferred.resolve(response.data);
        },function(reject){
          // error handler
          if(reject.status === 0) {
               deferred.reject("timeout");

          } else {
             // response error status from server
             //alert("internal server error");
              deferred.reject("internal server error");
          }
        }
        );
        return deferred.promise;
            //end
            }

            //Sites Lat Lng
            this.getSitesLatLng = function () {
                //alert("opening times for site obj - "+siteObj);
                return $http.get(this.restApiUrl + "?id=getsiteslatlng").then(function (response) {
                    return response.data;
                });
           }

    });
