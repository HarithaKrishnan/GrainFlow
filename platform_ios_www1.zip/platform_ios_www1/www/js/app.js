// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('cargill.grainflow', ['ionic', 'cargill.grainflow.controllers', 'cargill.grainflow.services'])

.run(function ($ionicPlatform, $ionicLoading, $rootScope) {

    $rootScope.$on('loading:show', function () {
        $ionicLoading.show({ content: '<i class="ion-loading-a"></i>', showBackdrop: false,showDelay: 500 })
    })



    $rootScope.$on('loading:hide', function () {
        $ionicLoading.hide()
    })

  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
    //Aravind - commented out the following if condition
    //Ashok - Below code hide IOS keypad next/prev/done options on dropdown lists
    /*if(window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
    }*/
    if(window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }

      if(ionic.Platform.isAndroid()) //iOS works fine
        {
            window.addEventListener("native.showkeyboard", function(){ //hide stuff on keyboard open
                if(document.getElementsByTagName("body")[0].className.indexOf("keyboard-body") === -1)
                {
                    //this event tends to fire multiple times, so we just add the class if it's not already there.
                    //Otherwise we'll end up with this class repeated.
                    document.getElementsByTagName("body")[0].className += " keyboard-body";
                }
            });
            window.addEventListener("native.hidekeyboard", function(){ //show stuff on keyboard hide
                document.getElementsByTagName("body")[0].className = document.getElementsByTagName("body")[0].className.replace("keyboard-body", "");
            });
        }
  });
})

.config(function ($stateProvider, $urlRouterProvider, $httpProvider) {

    $httpProvider.interceptors.push(function ($rootScope) {
        return {
            request: function (config) {
                $rootScope.$broadcast('loading:show')
                return config
            },
            response: function (response) {
                $rootScope.$broadcast('loading:hide')
                return response
            }
        }
    })


    $stateProvider

      .state('app', {
          url: "/app",
          abstract: true,
          templateUrl: "templates/menu.html",
          controller: 'menuCtrl'
      })

     .state('app.home', {
         url: "/home",
         views: {
             'menuContent': {
                 templateUrl: "templates/home.html",
                 controller: 'homeCtrl'
                /* resolve: {
                     'sites': function (grainFlowService) {
                         // MyServiceData will also be injectable in your controller, if you don't want this you could create a new promise with the $q service
                         return grainFlowService.getAllSites;
                     }
                 }*/
             }
         }
     })
      .state('app.myfavourites', {
          url: "/myfavourites",
          views: {
              'menuContent': {
                  templateUrl: "templates/myfavourites.html",
                  controller: 'favouritesCtrl'
              }
          }
      })

      .state('app.pricesearch', {
          url: "/pricesearch",
          views: {
              'menuContent': {
                  templateUrl: "templates/pricesearch.html",
                  controller: 'grainPrices',
                  resolve: {
                      'sites': function (grainFlowService) {
                          // MyServiceData will also be injectable in your controller, if you don't want this you could create a new promise with the $q service
                          return grainFlowService.getAllSites;
                      },
                      'buyers': function (grainFlowService) {
                          return grainFlowService.getAllBuyers;
                      },
                      'commodites': function (grainFlowService) {
                          return grainFlowService.getAllCommodites;
                      },
                      'getGrainPrices': function (grainFlowService) {
                          return grainFlowService.getGrainPrices;
                      }
                  }
              }
          }
      })
      .state('app.sitesbystate', {
          url: "/sitesbystate",
            views: {
                'menuContent': {
                    templateUrl: "templates/sitesbystate.html",
                    controller: 'sitesByStateCtrl'
                }
            }
      })

        .state('app.tabs', {
            url: "/selectedsitedetails",
            views: {
                'menuContent': {
                    templateUrl: "templates/selectedsitedetails.html",
                    controller: 'siteContactCtrl'
                }
            }
        })

.state('app.siteopeninghours', {
            url: "/siteopeninghours",
            views: {
                'menuContent': {
                    templateUrl: "templates/siteopeninghours.html",
                    controller: 'siteContactCtrl'
                }
            }
        })

        .state('app.siteturnaroundtime', {
            url: "/siteturnaroundtime",
            views: {
                'menuContent': {
                    templateUrl: "templates/siteturnaroundtime.html",
                    controller: 'siteContactCtrl'
                }
            }
        })

        .state('app.sitesegregations', {
            url: "/sitesegregations",
            views: {
                'menuContent': {
                    templateUrl: "templates/sitesegregations.html",
                    controller: 'siteContactCtrl'
                }
            }
        })
       .state('app.moreInfoList', {
           url: "/moreInfoList",
           views: {
               'menuContent': {
                   templateUrl: "templates/moreinfolist.html",
                   controller: 'moreInfoListCtrl'
               }
           }
       })
        .state('app.helpguide', {
            url: "/helpguide",
            views: {
                'menuContent': {
                    templateUrl: "templates/helpguide.html",
                    controller: 'helpGuideCtrl'
                }
            }
        })

        .state('app.apptandcs', {
            url: "/apptandcs",
            views: {
                'menuContent': {
                    templateUrl: "templates/apptandcs.html",
                    controller: 'appTermsAndConditionsCtrl'
                }
            }
        })

         .state('app.otherinfo', {
             url: "/otherinfo",
             views: {
                 'menuContent': {
                     templateUrl: "templates/otherinfo.html",
                     controller:'otherInfoCtrl'
                 }
             }
         })

         .state('app.vc', {
             url: "/vc",
             views: {
                 'menuContent': {
                     templateUrl: "templates/vc.html",
                     controller:'versionControlCtrl'
                 }
             }
         })
         .state('app.growerlogin', {
             url: "/growerlogin",
             views: {
                 'menuContent': {
                     templateUrl: "templates/growerlogin.html",
                     controller:'growerCtrl'
                 }
             }
         })
        .state('app.shs', {
            url: "/shs",
            views: {
                'menuContent': {
                    templateUrl: "templates/shs.html",
                    controller:'siteHealthAndSafetyCtrl'
                }
            }
        })
       .state('app.selectedsiteonmap', {
           url: "/selectedsiteonmap/:item",
           views: {
               'menuContent': {
                   templateUrl: "templates/selectedsiteonmap.html",
                   controller: 'selectedSiteOnMapCtrl',
                   resolve: {
                       'SitesLatLng': function (grainFlowService) {
                           return grainFlowService.getSitesLatLng;
                       }
                   }
               }
           }
       })
        .state('app.favpricesearch', {
            url: "/favpricesearch/:item",
            views: {
                'menuContent': {
                    templateUrl: "templates/favpricesearch.html",
                    controller: 'grainPricesForSelctedFavourite'
                }
            }
        })
    .state('app.callgrainflow', {
            url: "/callgrainflow",
            views: {
                'menuContent': {
                    templateUrl: "templates/callgrainflow.html",
                    controller: 'grainflowCtrl'
                }
            }
        })


      .state('app.single', {
          url: "/moreInfoList/:item",
          views: {
              'menuContent': {
                  templateUrl: "templates/moreinfodetails.html",
                  controller: 'moreInfoListDetailsCtrl'
              }
          }
      });


    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/app/home');
});
