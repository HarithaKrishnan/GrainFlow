# cordova-support-google-services
> Cordova plugin to add google service support

As part of enabling Google APIs or Firebase services in your Android application you may have to add the [google-services plugin](https://developers.google.com/android/guides/google-services-plugin) to your `build.gradle` file.

## Installation

    cordova plugin add cordova-support-google-services --save

Read details about the gradle plugin at https://developers.google.com/android/guides/google-services-plugin.
